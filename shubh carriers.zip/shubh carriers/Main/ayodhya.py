from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException, StaleElementReferenceException
from bs4 import BeautifulSoup
from selenium.webdriver.common.action_chains import ActionChains
import time
import logging
from webdriver_manager.chrome import ChromeDriverManager
import json
import datetime
import os
from concurrent.futures import ThreadPoolExecutor, as_completed  # Added this import
# Set up logging
logging.basicConfig(
    filename='tryAYODHYA.log',
    level=logging.INFO,
    format='%(asctime)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)



# Get the depot name from the script filename
depot_name = "AYODHYA"
'''Try to read quantities from a file first
quantities_file = f"{depot_name.lower()}_quantities.txt"
if os.path.exists(quantities_file):
    with open(quantities_file, 'r') as f:
        quantities_input = f.read().strip()
    print(f"Read quantities from file: {quantities_input}")
else:
    # Fall back to stdin if the file doesn't exist
    quantities_input = input("Enter desired quantities (separated by commas): ")

desired_quantities = [float(q.strip()) for q in quantities_input.split(",")]
logging.info(f"User specified quantities: {desired_quantities}")
print(f"Will bid for quantities: {desired_quantities}")
'''
# Global variable for destinations
desired_quantities = []
destinations = {}

# Use a list of tuples or a dictionary of lists
quantity_destination_pairs = []  # [(quantity, destination), ...]


# Define available destinations for each depot
destinations_by_depot = {
    "AYODHYA": [
        "AYODHYA", "SALARPUR (FZB)", "DYORHI BAZAR", "KHAJURAHAT", "KUMARGANJ", 
        "MASAUDHA", "KUCHERA BAZAR", "RUDAULI", "SOHAWAL", "POORA BAZAR", 
        "MILKIPUR (FZB)", "MAWAI", "RAJE SULTANPUR (AMB)","RUDAULI-DUMP", 
        "BEEKAPUR", "RANIMAU (FZBD)","BHETE",
        "DEORIA BAZAR" , "JAHANGIR GANJ","AKBARPUR (ABD)","MAHRUWA","MALIPUR (AMD NAGAR)", "RAMGARH (AMD NAGAR)",
        "BASKARI","Jalalpur","NEORA","BANDIPUR", "RAFIGANJ","CHATURI PATTI","RAMNAGAR MAHUWARE","RAMPUR SARKARWAL",
        "MAYA BAZAR", "CHAURE BAZAR", "KHANDASA", "BELSAR", "FAIZABAD-1-DUMP"
    ]
}
# Get available destinations for the depot
available_destinations = destinations_by_depot.get(depot_name, [])
if available_destinations:
    print(f"\nAvailable destinations for {depot_name}:")
    for i, dest in enumerate(available_destinations):
        print(f"{i+1}. {dest}")

# Function to collect quantity-destination pairs
def collect_quantity_destination_pairs():
    while True:
        try:
            quantity_input = input("\nEnter a desired quantity (or press Enter to finish): ").strip()
            if not quantity_input:
                break
                
            quantity = float(quantity_input)
            desired_quantities.append(quantity)
            
            # Ask for destination
            if available_destinations:
                dest_input = input(f"Enter destination number for quantity {quantity} (or press Enter to skip): ").strip()
                if dest_input:
                    dest_idx = int(dest_input) - 1
                    if 0 <= dest_idx < len(available_destinations):
                        destination = available_destinations[dest_idx]
                        quantity_destination_pairs.append((quantity, destination))
                        print(f"Added quantity {quantity} with destination {destination}")
                    else:
                        print(f"Invalid destination number. No destination set for {quantity}.")
                        quantity_destination_pairs.append((quantity, None))
                else:
                    print(f"No destination set for quantity {quantity}")
                    quantity_destination_pairs.append((quantity, None))
            else:
                quantity_destination_pairs.append((quantity, None))
                
        except ValueError:
            print("Please enter a valid number")

# Collect the quantity-destination pairs
collect_quantity_destination_pairs()

# Verify we have at least one quantity
if not desired_quantities:
    print("No quantities specified. Exiting.")
    logging.error("No quantities specified. Exiting.")
    exit()

# Print summary of quantities and destinations
print("\nBidding for:")
for qty, dest in quantity_destination_pairs:
    dest_info = f", destination: {dest}" if dest else ""
    print(f"Quantity: {qty}{dest_info}")
logging.info(f"User specified quantities and destinations: {quantity_destination_pairs}")



# Data structures for storing bid information
data_set = []
data_set_clubid_list = []
dataSingle = []  # For single bids

# Global variables
count = 0
singleCount = 0
quantity_bids = {qty: [] for qty in desired_quantities}



def add_data(rowid, amount, destination=None):
    # Create the data dictionary BEFORE checking for duplicates
    data = {
        "rowid": rowid,
        "amount": amount,
        "destination": destination
    }
    
    # Check if the row already exists in data_set
    if not any(existing['rowid'] == rowid for existing in data_set):
        data_set.append(data)
    
    # Also add to dataSingle
    dataSingle.append(data)

def data_set_clubid(rowid, amount, clubid, destination=None):
    data = {
        "rowid": rowid,
        "amount": amount,
        "clubid": clubid,
        "destination": destination
    }
    data_set_clubid_list.append(data)





def get_timer_info(driver):
    """Get timer information from the webpage."""
    try:
        timer_element = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.ID, '__xmlview0--timer-inner'))
        )
        timer_text = timer_element.text
        return timer_text
    except (NoSuchElementException, TimeoutException) as e:
        logging.error(f"Error getting timer information: {e}")
        return "Timer not found"


def wait_for_timer_and_click_search2():
    try:
        while True:
            try:
                timer2_element = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.ID, '__xmlview0--timer-inner'))
                )
                current_time = timer2_element.text
                print(f"Current timer: {current_time}")
                logging.info(f"Current timer: {current_time}")
                
                # Specifically target 4 seconds
                if current_time == 'Starts in 0:0:4':
                    search_box = WebDriverWait(driver, 5).until(
                        EC.element_to_be_clickable((By.ID, '__button3-BDI-content'))
                    )
                    search_box.click()
                    print("Clicked search at exactly 4 seconds")
                    logging.info("Clicked search at exactly 4 seconds")
                    break
                
                elif 'Expires in' in current_time:
                    print("Bid is active with 'Expires in' timer.")
                    logging.info("Bid is active with 'Expires in' timer.")
                    break
                    
            except StaleElementReferenceException:
                print("StaleElementReferenceException occurred. Retrying...")
                logging.warning("StaleElementReferenceException occurred. Retrying...")
                continue
                
            time.sleep(0.1)  # Reduced sleep time for more precise checking
    except (NoSuchElementException, TimeoutException) as e:
        print(f"Error tracking the timer or clicking the search box: {e}")
        logging.error(f"Error tracking the timer or clicking the search box: {e}")
        return False

def print_updated_row(row_id):
    try:
        # Wait for the table to refresh after bid submission
        time.sleep(1)
        
        # Find the table body
        tbody = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, '__xmlview0--idUtclVCVendorAssignmentTable-tblBody'))
        )
        
        # Get updated table content
        tbody_html = tbody.get_attribute('outerHTML')
        soup = BeautifulSoup(tbody_html, 'html.parser')
        rows = soup.find_all('tr')
        
        # Find the specific row by row_id
        current_row_id = -1
        for row in rows:
            current_row_id += 1
            if current_row_id == row_id:
                cells = row.find_all('td')
                cell_data = [cell.get_text(strip=True) for cell in cells]
                
                # Extract destination
                destination = cell_data[5] if len(cell_data) > 5 else None
                dest_info = f", destination: {destination}" if destination else ""
                
                # Print and log the updated row data
                print(f"Updated row {row_id} data{dest_info}: {cell_data}")
                logging.info(f"Updated row {row_id} data{dest_info}: {cell_data}")
                return True
        
        print(f"Row {row_id} not found in the updated table")
        logging.warning(f"Row {row_id} not found in the updated table")
        return False
        
    except Exception as e:
        print(f"Error retrieving updated row {row_id}: {e}")
        logging.error(f"Error retrieving updated row {row_id}: {e}")
        return False
    
def enter_bid_for_single_item(item):
    try:
        input_id = f"__xmlview0--idBidAmount-__xmlview0--idUtclVCVendorAssignmentTable-{item['rowid']}-inner"
        bid_amt = int(item['amount'])
        
        # Get destination info for logging
        dest_info = f", destination: {item['destination']}" if 'destination' in item and item['destination'] else ""
        
        # Use a more robust wait with retry logic
        max_retries = 3
        for attempt in range(max_retries):
            try:
                # Wait for the input field to be present and clickable
                bid_input = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.ID, input_id))
                )
                
                # Use JavaScript to ensure the element is in view
                driver.execute_script("arguments[0].scrollIntoView(true);", bid_input)
                
                # Clear and enter the bid amount
                bid_input.clear()
                bid_input.send_keys(str(bid_amt))
                print(f"Entered bid amount: {bid_amt} for row {item['rowid']}{dest_info}")
                logging.info(f"Entered bid amount: {bid_amt} for row {item['rowid']}{dest_info}")
                return True
            except StaleElementReferenceException:
                if attempt < max_retries - 1:
                    print(f"Stale element on attempt {attempt+1}, retrying...")
                    logging.warning(f"Stale element on attempt {attempt+1}, retrying...")
                    time.sleep(1)
                else:
                    raise
    except Exception as e:
        print(f"Error entering bid for row {item['rowid']}: {e}")
        logging.error(f"Error entering bid for row {item['rowid']}: {e}")
        return False

def enter_bid_amount_and_save():
    try:
        if singleCount > 0:
            # Use a set to track processed rows
            processed_rows = set()
            
            def enter_bid_for_single_item(item):
                # Check if this row has already been processed
                if item['rowid'] in processed_rows:
                    print(f"Row {item['rowid']} already processed, skipping")
                    return True
                
                try:
                    input_id = f"__xmlview0--idBidAmount-__xmlview0--idUtclVCVendorAssignmentTable-{item['rowid']}-inner"
                    bid_amt = int(item['amount'])
                    
                    # Wait for the input field to be present and clickable
                    bid_input = WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((By.ID, input_id))
                    )
                    
                    # Use JavaScript to ensure the element is in view
                    driver.execute_script("arguments[0].scrollIntoView(true);", bid_input)
                    
                    # Clear and enter the bid amount
                    bid_input.clear()
                    bid_input.send_keys(str(bid_amt))
                    
                    # Mark this row as processed
                    processed_rows.add(item['rowid'])
                    
                    print(f"Entered bid amount: {bid_amt} for row {item['rowid']}")
                    return True
                
                except Exception as e:
                    print(f"Error entering bid for row {item['rowid']}: {e}")
                    return False
            
            # Deduplicate dataSingle before processing
            unique_data_single = []
            seen_rowids = set()
            for item in dataSingle:
                if item['rowid'] not in seen_rowids:
                    unique_data_single.append(item)
                    seen_rowids.add(item['rowid'])
            
            # Process unique rows
            for item in unique_data_single:
                enter_bid_for_single_item(item)
            
            # Use ThreadPoolExecutor with a controlled number of workers
            with ThreadPoolExecutor(max_workers=min(10, singleCount)) as executor:
                # Submit all bid entry tasks to the executor
                futures = [executor.submit(enter_bid_for_single_item, item) for item in dataSingle]
                
                # Wait for all futures to complete and handle results
                for future in as_completed(futures):
                    try:
                        result = future.result()
                        if not result:
                            print("A bid entry task failed")
                    except Exception as exc:
                        print(f"Task generated an exception: {exc}")
            
            # After entering all bid amounts in parallel, click save with retry logic
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    save_button = WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((By.ID, '__xmlview0--idUtclsaveTxt-inner'))
                    )
                    
                    # Use JavaScript to ensure the save button is in view
                    driver.execute_script("arguments[0].scrollIntoView(true);", save_button)
                    
                    # Click the save button
                    save_button.click()
                    print("Save button clicked.")
                    logging.info("Save button clicked.")
                    
                    # Wait for confirmation dialog to appear
                    time.sleep(0.2)  # Increased wait time for dialog to appear
                    
                    # Try multiple approaches to confirm the first dialog (Yes button)
                    confirmation_methods = [
                        # Method 1: Find by ID and click directly
                        lambda: WebDriverWait(driver, 8).until(
                            EC.element_to_be_clickable((By.XPATH, "//bdi[text()='Yes']/ancestor::button"))
                        ).click(),

                        
                        # Method 2: Find by ID and click via JavaScript
                        lambda: driver.execute_script(
                            "document.getElementById('__mbox-btn-0').click();"
                        ),
                        
                        # Method 3: Find by querySelector and click via JavaScript
                        lambda: driver.execute_script(
                            "document.querySelector('#__mbox-btn-0').click();"
                        ),
                        
                        # # Method 4: Find by XPath for button content
                        # lambda: WebDriverWait(driver, 8).until(
                        #     EC.element_to_be_clickable((By.ID, '__mbox-btn-0'))
                        # ).click(),
                        
                        # # Method 5: Find by XPath for direct path
                        # lambda: WebDriverWait(driver, 8).until(
                        #     EC.element_to_be_clickable((By.XPATH, "/html/body/div[1]/div[4]/footer/div/button[1]"))
                        # ).click(),
                        
                        # # Method 6: Find by text content and click via JavaScript
                        # lambda: driver.execute_script(
                        #     "Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Yes')).click();"
                        # ),
                        
                        # # Method 7: Send Enter key as last resort
                        # lambda: ActionChains(driver).send_keys(Keys.ENTER).perform()
                    ]
                    
                    # Try each method until one succeeds
                    for i, method in enumerate(confirmation_methods):
                        try:
                            method()
                            print(f"First confirmation dialog (Yes) handled successfully with method {i+1}")
                            logging.info(f"First confirmation dialog (Yes) handled successfully with method {i+1}")
                            break
                        except Exception as e:
                            print(f"Method {i+1} failed for Yes button: {e}")
                            logging.warning(f"Method {i+1} failed for Yes button: {e}")
                            if i == len(confirmation_methods) - 1:
                                print("All confirmation methods failed for Yes button")
                                logging.error("All confirmation methods failed for Yes button")
                    
                    # Wait for the second dialog (OK button) to appear
                    time.sleep(0.2)
                    
                    # Try multiple approaches to confirm the second dialog (OK button)
                    ok_dialog_methods = [
                        # Method 1: Find by ID and click directly
                        lambda: WebDriverWait(driver, 8).until(
                            EC.element_to_be_clickable((By.XPATH, "//bdi[text()='OK']/ancestor::button"))
                        ).click(),                        
                        
                        # Method 2: Find by ID and click via JavaScript
                        lambda: driver.execute_script(
                            "document.getElementById('__mbox-btn-4').click();"
                        ),
                        
                        # Method 3: Find by querySelector and click via JavaScript
                        lambda: driver.execute_script(
                            "document.querySelector('#__mbox-btn-4').click();"
                        ),
                        
                        # Method 4: Find by XPath for button content
                        
                        lambda: WebDriverWait(driver, 8).until(
                            EC.element_to_be_clickable((By.ID, '__mbox-btn-4'))
                        ).click(),
                        
                        # # Method 5: Find by XPath using the provided selector
                        # lambda: WebDriverWait(driver, 8).until(
                        #     EC.element_to_be_clickable((By.XPATH, "//*[@id='__mbox-btn-4']"))
                        # ).click(),
                        
                        # # Method 6: Find by text content and click via JavaScript
                        # lambda: driver.execute_script(
                        #     "Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('OK')).click();"
                        # ),
                        
                        # # Method 7: Send Enter key as last resort
                        # lambda: ActionChains(driver).send_keys(Keys.ENTER).perform()
                    ]
                    
                    # Try each method until one succeeds for the OK button
                    for i, method in enumerate(ok_dialog_methods):
                        try:
                            method()
                            print(f"Second confirmation dialog (OK) handled successfully with method {i+1}")
                            logging.info(f"Second confirmation dialog (OK) handled successfully with method {i+1}")
                            break
                        except Exception as e:
                            print(f"Method {i+1} failed for OK button: {e}")
                            logging.warning(f"Method {i+1} failed for OK button: {e}")
                            if i == len(ok_dialog_methods) - 1:
                                print("All confirmation methods failed for OK button")
                                logging.error("All confirmation methods failed for OK button")
                    
                    # Add delay after confirming both dialogs
                    print("Retrieving updated bid information...")
                    logging.info("Retrieving updated bid information...")

                    # Print updated information for each row that was updated
                    for item in dataSingle:
                        print_updated_row(item['rowid'])
                    
                    time.sleep(60)
                    
                    break
                except StaleElementReferenceException:
                    if attempt < max_retries - 1:
                        print(f"Stale element on save button attempt {attempt+1}, retrying...")
                        logging.warning(f"Stale element on save button attempt {attempt+1}, retrying...")
                        time.sleep(1)
                    else:
                        raise
                        
    except Exception as e:
        print(f"Error entering bid amount or saving: {e}")
        logging.error(f"Error entering bid amount or saving: {e}")

def process_bids(rows):
    global count, singleCount, dataSingle
    
    # Reset counters and data for this depot
    dataSingle = []
    singleCount = 0
    count = 0
    found_any_match = False
    
    # Tracking used rows to prevent reusing
    used_rows = set()
    used_club_ids = set()
    
    # Excluded companies list
    excluded_companies = [
        'BHIM LAL JAISWAL', 'RAJU BUILDING MATERIAL', 'MAHALASA CONSTRUCTIONS PVT LTD', 
        'ABHILASHA ENTERPRISES', 'PAHALWAN TRADERS', 'TARIKH BULD. MATERIAL', 
        'PRANJAL ENTERPRISES', 'OM SAI TRADERS'
    ]
    
    # Store all rows with their data for processing
    all_rows = []
    
    # Function to print table details
    def print_table_details(rows):
        print("\n--- Available Bids Table ---")
        print("{:<5} {:<15} {:<15} {:<20} {:<20} {:<15} {:<15}".format(
            "Row", "Club ID", "Quantity", "Destination", "Company", "Base Price", "Bid Price"
        ))
        print("-" * 110)
        
        for rowid, row in enumerate(rows):
            cells = row.find_all('td')
            cell_data = [cell.get_text(strip=True) for cell in cells]
            
            # Extract relevant details
            try:
                club_identifier = cell_data[2].replace("Object Identifier", "").strip()
                current_clubid = int(club_identifier) if club_identifier else 0
                
                quantity = float(cell_data[11]) if len(cell_data) > 10 and cell_data[11].replace('.', '', 1).isdigit() else 0
                destination = cell_data[5] if len(cell_data) > 5 else 'N/A'
                company = cell_data[20] if len(cell_data) > 20 else 'N/A'
                
                # Calculate bid amount - 2% less than the base price
                if len(cell_data) > 13 and cell_data[13].replace('.', '', 1).isdigit():
                    base_price = int(cell_data[13])
                    val = (base_price * 2) // 100
                    bid_price = int(base_price - val)
                else:
                    base_price = 'N/A'
                    bid_price = 'N/A'
                
                print("{:<5} {:<15} {:<15} {:<20} {:<20} {:<15} {:<15}".format(
                    rowid, current_clubid, quantity, destination, company, base_price, bid_price
                ))
            except Exception as e:
                print(f"Error processing row {rowid}: {e}")
        
        print("-" * 110)
    
    # Print table details
    print_table_details(rows)
    
    # First pass: gather all row data
    rowid = -1
    for row in rows:
        rowid += 1
        cells = row.find_all('td')
        cell_data = [cell.get_text(strip=True) for cell in cells]
        
        # Skip row if insufficient data
        if len(cell_data) <= 12:
            continue
        
        # Check if the company is in the excluded list
        if len(cell_data) > 20 and cell_data[20] in excluded_companies:
            continue
        
        # Extract club ID
        try:
            club_identifier = cell_data[2].replace("Object Identifier", "").strip()
            current_clubid = int(club_identifier) if club_identifier else 0
        except (ValueError, IndexError):
            current_clubid = 0
        
        # Extract quantity
        try:
            quantity = float(cell_data[11]) if len(cell_data) > 10 and cell_data[11].replace('.', '', 1).isdigit() else 0
        except (ValueError, IndexError):
            quantity = 0
        
        # Extract destination
        destination = cell_data[5] if len(cell_data) > 5 else None
        
        # Calculate bid amount - 2% less than the base price
        if len(cell_data) > 13 and cell_data[13].replace('.', '', 1).isdigit():
            value_to_calculate = int(cell_data[13])
            val = (value_to_calculate * 2) // 100
            final_bid = int(value_to_calculate - val)
            
            # Store row data for processing
            row_data = {
                'rowid': rowid,
                'quantity': quantity,
                'bid_amount': final_bid,
                'clubid': current_clubid,
                'cell_data': cell_data,
                'destination': destination
            }
            
            all_rows.append(row_data)
    
    # Function to check if a row is valid for single bid
    def is_valid_for_single_bid(row):
        # Strictly prevent rows with non-zero club IDs from being selected for single bids
        return row['clubid'] == 0
    
    # Add logging for quantities being processed
    logging.info(f"Processing bids for quantities: {quantity_destination_pairs}")
    
    # Process each desired quantity
    unmatched_quantities = []
    for desired_quantity, desired_destination in quantity_destination_pairs:
        # Filter rows by destination if specified
        filtered_rows = all_rows
        if desired_destination:
            filtered_rows = [
                row for row in all_rows 
                if row['destination'] == desired_destination
            ]
        
        # Filter out previously used rows
        filtered_rows = [
            row for row in filtered_rows 
            if row['rowid'] not in used_rows and row['clubid'] not in used_club_ids
        ]
        
        # Separate rows by club ID
        rows_by_clubid = {}
        rows_without_clubid = []
        
        for row in filtered_rows:
            if row['clubid'] > 0:
                if row['clubid'] not in rows_by_clubid:
                    rows_by_clubid[row['clubid']] = []
                rows_by_clubid[row['clubid']].append(row)
            else:
                rows_without_clubid.append(row)
        
        # Find match
        match_found = False
        
        # CASE 1: Find club ID group match (FIRST PRIORITY)
        for clubid, group in rows_by_clubid.items():
            total_quantity = sum(row['quantity'] for row in group)
            if abs(total_quantity - desired_quantity) < 0.01:
                logging.info(f"Found club ID group match: Club ID {clubid}, Total Quantity: {total_quantity}")
        
                bids_for_quantity = []
                for row in group:
                    add_data(row['rowid'], row['bid_amount'], row['destination'])
                    bids_for_quantity.append({
                        'rowid': row['rowid'], 
                        'amount': row['bid_amount'], 
                        'destination': row['destination']
                    })
                    
                    # Mark these rows as used
                    used_rows.add(row['rowid'])
                
                # Mark this club ID as used
                used_club_ids.add(clubid)
                
                quantity_bids[desired_quantity] = bids_for_quantity
                singleCount += len(bids_for_quantity)
                found_any_match = True
                match_found = True
                break  # Only break from the clubid loop, not the quantity loop
        
        # CASE 2: If no club ID group match, find exact single row match
        if not match_found:
            exact_matches = [
                row for row in rows_without_clubid 
                if abs(row['quantity'] - desired_quantity) < 0.01 and is_valid_for_single_bid(row)
            ]
            
            if exact_matches:
                row = exact_matches[0]
                logging.info(f"Found exact single row match: Row {row['rowid']}, Quantity: {row['quantity']}")
                
                add_data(row['rowid'], row['bid_amount'], row['destination'])
                quantity_bids[desired_quantity] = [{
                    'rowid': row['rowid'], 
                    'amount': row['bid_amount'], 
                    'destination': row['destination']
                }]
                
                # Mark this row as used
                used_rows.add(row['rowid'])
                
                singleCount += 1
                count += 1
                found_any_match = True
                match_found = True
        
        # If no match found for this quantity
        if not match_found:
            logging.warning(f"Could not find rows matching quantity {desired_quantity}")
            unmatched_quantities.append(desired_quantity)
    
    # Log unmatched quantities
    if unmatched_quantities:
        print("\nWarning: Could not find bids for the following quantities:")
        for qty in unmatched_quantities:
            print(f"- {qty}")
            
    # Return True if any matches were found, False otherwise
    return found_any_match


def perform_search_and_process():
    global singleCount, dataSingle, data_set, data_set_clubid_list, quantity_bids
    
    # Reset all bid data
    data_set = []
    data_set_clubid_list = []
    dataSingle = []
    singleCount = 0
    
    # Initialize bids for each quantity
    quantity_bids = {qty: [] for qty in desired_quantities}
    
    try:
        search_box = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, '__button3-BDI-content')))
        search_box.click()
        logging.info("Search button clicked")
        
        # Wait for results to load
        time.sleep(1)
        
        # Check if there's a table with data
        try:
            tbody = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.ID, '__xmlview0--idUtclVCVendorAssignmentTable-tblBody'))
            )
            
            # Get timer information
            timer_info = get_timer_info(driver)
            logging.info(f"Current timer status: {timer_info}")
            
            # Get table content
            tbody_html = tbody.get_attribute('outerHTML')
            soup = BeautifulSoup(tbody_html, 'html.parser')
            rows = soup.find_all('tr')
            
            if len(rows) > 0:
                first_row = rows[0]
                cells = first_row.find_all('td')
                cell_data = [cell.get_text(strip=True) for cell in cells]
                
                if 'No data' in cell_data:
                    logging.info("Search result: No bids available")
                    return False
                else:
                    bid_count = len(rows)
                    logging.info(f"Search result: {bid_count} bids found with timer: {timer_info}")
                    
                    # Process bids based on desired quantities
                    print(f"Processing bids with desired quantities: {desired_quantities}")
                    logging.info(f"Processing bids with desired quantities: {desired_quantities}")

                    # Process bids
                    found_qualifying_bids = process_bids(rows)
                    
                    if found_qualifying_bids:
                        # If qualifying bids found, wait for timer and then place bids
                        logging.info("Qualifying bids found, watching timer")
                        wait_for_timer_and_click_search2()
                        logging.info("Timer function completed, proceeding to enter bid amounts")
                        print("Timer function completed, proceeding to enter bid amounts")

                        # After timer expires, enter bids and save
                        enter_bid_amount_and_save()
                        logging.info("Bid amounts entered and saved")
                        return True
                    else:
                        logging.info("No qualifying bids found")
                        return False
            else:
                logging.info("Search result: Empty table (no rows)")
                return False
                
        except (NoSuchElementException, TimeoutException) as e:
            logging.info("No table found, likely no bids available")
            return False
            
    except Exception as e:
        logging.error(f"Error during search and processing operation: {e}")
        return False


# Initialize browser
try:
    brave_path = "C:/Program Files/BraveSoftware/Brave-Browser/Application/brave.exe"

    options = Options()
    options.binary_location = brave_path
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

    driver.get('https://www.eye2serve.com:9001/sap/bc/ui5_ui5/ui2/ushell/shells/abap/FioriLaunchpad.html')

    # Login
    username_field = driver.find_element(By.ID, 'USERNAME_FIELD-inner')
    password_field = driver.find_element(By.ID, 'PASSWORD_FIELD-inner')

    username_field.send_keys('2900034')
    password_field.send_keys('Devesh3321@#')
    password_field.send_keys(Keys.RETURN)

    time.sleep(6)
    logging.info("Logged in to the system")

    # Click on E-Bidding button
    try:
        ebidding_button = WebDriverWait(driver, 30).until(EC.presence_of_element_located((By.ID, '__content6')))
        ebidding_button.click()
        logging.info("Clicked on E-Bidding button")
    except (NoSuchElementException) as e:
        logging.error(f"Failed to click E-Bidding button: {e}")

    # Handle new tab and perform initial search
    original_handle = driver.current_window_handle
    try:
        WebDriverWait(driver, 10).until(EC.new_window_is_opened)
    except TimeoutException:
        logging.error("New tab didn't open within the specified time.")
        driver.quit()
        exit()

    for handle in driver.window_handles:
        if handle != original_handle:
            driver.switch_to.window(handle)
            break

    try:
        search_button = WebDriverWait(driver, 30).until(EC.presence_of_element_located((By.ID, '__button0-BDI-content')))
        search_button = WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.ID, '__button0-BDI-content')))
        search_button.click()
        logging.info("Clicked on initial search button in new tab")
    except (NoSuchElementException, TimeoutException) as e:
        logging.error(f"Error finding or clicking search button: {e}")
        driver.quit()
        exit()

    # Enter fixed search criteria
    try:
        # Enter the fixed ship from plant
        ship_box = WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.ID, '__xmlview0--ididUtclVCShipFromPlant-inner')))
        time.sleep(1)
        ship_box.send_keys('TANDA CEMENT WORKS')
        logging.info("Entered 'TANDA CEMENT WORKS' in ship from plant field")
        
        # Enter the fixed depot
        ship_box2 = WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.ID, '__xmlview0--idUtclVCDepot-inner')))
        time.sleep(1)
        ship_box2.send_keys('AYODHYA')
        logging.info("Entered 'AYODHYA' in depot field")
    except (NoSuchElementException) as e:
        logging.error(f"Error entering search criteria: {e}")

    # Initial search
    bids_found = perform_search_and_process()

    # Continue searching every 10 seconds until qualifying bids are found
    try:
        if not bids_found:
            logging.info("Starting continuous search loop every 10 seconds until qualifying bids are found")
            while not bids_found:
                time.sleep(10)
                logging.info("Performing periodic search...")
                bids_found = perform_search_and_process()
                
        if bids_found:
            logging.info("Qualifying bids found and processed. Keeping session open.")
            # Keep the session open - add a loop to keep the script running
            while True:
                try:
                    time.sleep(60)  # Check every minute
                    logging.info("Session maintained. Press Ctrl+C to exit.")
                except KeyboardInterrupt:
                    raise KeyboardInterrupt
        else:
            logging.info("No qualifying bids found. Keeping session open.")
            while True:
                try:
                    time.sleep(60)  # Check every minute
                    logging.info("Session maintained. Press Ctrl+C to exit.")
                except KeyboardInterrupt:
                    raise KeyboardInterrupt                                            
    except KeyboardInterrupt:
        logging.info("Script terminated by user")
        driver.quit()
except Exception as e:
    logging.error(f"Error occurred: {e}")
    driver.quit()
    