import subprocess
import sys
import os
import time
import threading
import logging
from datetime import datetime

# Configure logging
log_dir = "logs"
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

log_filename = os.path.join(log_dir, f"multi_depot_bidding_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
logging.basicConfig(
    filename=log_filename,
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

# Define depot options
depot_options = {
    1: "LUCKNOW",
    2: "AYODHYA", 
    3: "SITAPUR",
    4: "GONDA",
    5: "HARDOI", 
    6: "GORAKHPUR",
    7: "MAU",
    8: "DEORIA",
    9: "BASTI"
}

# Dictionary mapping depot names to their script files
depot_scripts = {
    "LUCKNOW": "lucknow_bidding.py",
    "AYODHYA": "ayodhya.py",
    "SITAPUR": "sitapur.py",
    "GONDA": "gonda.py",
    "HARDOI": "ayodhya18.py",
    "GORAKHPUR": "gorakhpur_bidding.py",
    "MAU": "mau_bidding.py",
    "DEORIA": "deoria_bidding.py",
    "BASTI": "basti_bidding.py"
}

# Store running processes
running_processes = {}
process_locks = {}

def run_depot_script(depot_name):
    """Run the bidding script for a specific depot. The script handles quantity input."""
    try:
        script_path = depot_scripts[depot_name]
        
        # Create log file for the specific depot
        depot_log = os.path.join(log_dir, f"{depot_name.lower()}_bidding_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
        
        # Check if the script file exists
        if not os.path.exists(script_path):
            error_msg = f"Script file for {depot_name} not found: {script_path}"
            logging.error(error_msg)
            print(f"ERROR: {error_msg}")
            return
        
        logging.info(f"Starting bidding script for {depot_name}")
        print(f"Starting {depot_name} bidding script...")
        
        # FIXED: The way we launch the script, using proper command construction
        if os.name == 'nt':  # Windows
            # Create a batch file to run the Python script
            batch_filename = f"run_{depot_name.lower()}_{datetime.now().strftime('%H%M%S')}.bat"
            with open(batch_filename, 'w') as batch_file:
                batch_file.write(f'@echo off\n')
                batch_file.write(f'title {depot_name} Bidding Process\n')
                batch_file.write(f'echo Starting {depot_name} bidding\n')
                batch_file.write(f'{sys.executable} {script_path}\n')
                batch_file.write('pause\n')  # Keep window open when done
            
            # Start the batch file in a new window
            process = subprocess.Popen(
                ['start', 'cmd', '/c', batch_filename],
                shell=True,
                text=True
            )
            
        else:  # Linux/Mac
            # For Linux/Mac, try to use xterm or another terminal
            script_command = f"{sys.executable} {script_path}"
            terminal_cmd = ['xterm', '-e', script_command]
            
            # Try common terminals if xterm isn't available
            terminals = ['xterm', 'gnome-terminal', 'konsole', 'terminal']
            success = False
            
            for terminal in terminals:
                try:
                    if terminal == 'gnome-terminal':
                        cmd = [terminal, '--', 'bash', '-c', script_command]
                    elif terminal == 'konsole':
                        cmd = [terminal, '-e', 'bash', '-c', script_command]
                    else:
                        cmd = [terminal, '-e', script_command]
                        
                    process = subprocess.Popen(cmd)
                    success = True
                    break
                except FileNotFoundError:
                    continue
            
            if not success:
                # Fallback to non-terminal mode
                process = subprocess.Popen(
                    [sys.executable, script_path],
                    stdout=open(depot_log, 'w'),
                    stderr=subprocess.STDOUT,
                    text=True
                )
        
        # Generate a unique ID for this depot instance
        instance_id = f"{depot_name}_{datetime.now().strftime('%H%M%S')}"
        
        # Create a lock for this process
        process_locks[instance_id] = threading.Lock()
        
        # Store the process with its unique ID
        with process_locks[instance_id]:
            running_processes[instance_id] = {
                "process": process,
                "depot_name": depot_name,
                "batch_file": batch_filename if os.name == 'nt' else None,
                "start_time": datetime.now()
            }
        
        logging.info(f"{depot_name} bidding script started successfully")
        print(f"{depot_name} bidding script started successfully")
        
    except Exception as e:
        error_msg = f"Error starting {depot_name} script: {str(e)}"
        logging.exception(error_msg)
        print(f"ERROR: {error_msg}")

def stop_depot_script(instance_id):
    """Stop the running script for a specific depot instance."""
    try:
        if instance_id in process_locks:
            with process_locks[instance_id]:
                if instance_id in running_processes:
                    process_info = running_processes[instance_id]
                    depot_name = process_info["depot_name"]
                    
                    logging.info(f"Stopping {depot_name} script")
                    print(f"Stopping {depot_name} script...")
                    
                    # Try to terminate gracefully first
                    process_info["process"].terminate()
                    
                    # Give it some time to terminate
                    time.sleep(1)
                    
                    # If still running, force kill
                    if process_info["process"].poll() is None:
                        process_info["process"].kill()
                    
                    logging.info(f"{depot_name} script stopped")
                    print(f"{depot_name} script stopped")
                    
                    # Clean up any temporary files
                    if os.name == 'nt' and process_info["batch_file"] and os.path.exists(process_info["batch_file"]):
                        try:
                            os.remove(process_info["batch_file"])
                        except Exception as e:
                            logging.warning(f"Could not remove batch file: {str(e)}")
                    
                    # Remove from running processes
                    del running_processes[instance_id]
    except Exception as e:
        logging.error(f"Error stopping script {instance_id}: {str(e)}")
        print(f"Error stopping script {instance_id}: {str(e)}")

def stop_all_scripts():
    """Stop all running depot scripts."""
    for instance_id in list(running_processes.keys()):
        stop_depot_script(instance_id)
    print("All scripts stopped")

def display_menu():
    """Display the main menu."""
    print("\n===== Multi-Depot Cement Bidding System =====")
    print("1. Start bidding for depots")
    # print("2. Stop a specific depot instance")
    # print("3. Stop all depots")
    # print("4. List running depot instances")
    print("2. Exit")
    print("============================================")

def main():
    """Main function to run the bidding system."""
    try:
        logging.info("Multi-Depot Cement Bidding System started")
        print("Multi-Depot Cement Bidding System started")
        
        while True:
            display_menu()
            choice = input("Enter your choice (1-5): ")
            
            if choice == '1':
                # Display available depots
                print("\nAvailable Depots:")
                for idx, depot in depot_options.items():
                    print(f"{idx}. {depot}")
                
                depot_input = input("\nEnter depot numbers (comma-separated, e.g., 1,2,3,1,2): ")
                try:
                    # Parse comma-separated depot numbers
                    selected_depot_nums = [int(d.strip()) for d in depot_input.split(",") if d.strip()]
                    
                    if not selected_depot_nums:
                        print("No depots selected!")
                        continue
                    
                    # Validate depot numbers and convert to depot names
                    selected_depots = []
                    for depot_num in selected_depot_nums:
                        if depot_num in depot_options:
                            selected_depots.append(depot_options[depot_num])
                        else:
                            print(f"Warning: Depot number {depot_num} is invalid and will be skipped.")
                    
                    if not selected_depots:
                        print("No valid depots selected!")
                        continue
                    
                    print(f"Selected depots: {', '.join(selected_depots)}")
                    
                    # Start bidding for each selected depot
                    for depot_name in selected_depots:
                        threading.Thread(target=run_depot_script, args=(depot_name,)).start()
                        # Short delay to prevent overwhelming the system
                        time.sleep(0.5)
                    
                except ValueError:
                    print("Invalid input! Please enter valid depot numbers separated by commas.")
            
            elif choice == '2':
                # Stop a specific depot instance
                if not running_processes:
                    print("No depot instances are currently running!")
                    continue
                
                print("\nRunning Depot Instances:")
                instance_list = list(running_processes.keys())
                for i, instance_id in enumerate(instance_list, 1):
                    info = running_processes[instance_id]
                    elapsed = datetime.now() - info["start_time"]
                    elapsed_str = f"{elapsed.seconds // 60}m {elapsed.seconds % 60}s"
                    print(f"{i}. {info['depot_name']} (Running for: {elapsed_str})")
                
                instance_to_stop = input("\nEnter the instance number to stop: ")
                try:
                    idx = int(instance_to_stop.strip())
                    if 1 <= idx <= len(instance_list):
                        instance_id = instance_list[idx - 1]
                        stop_depot_script(instance_id)
                    else:
                        print("Invalid instance number!")
                except ValueError:
                    print("Please enter a valid number!")
            
            elif choice == '3':
                # Stop all depots
                if not running_processes:
                    print("No depot instances are currently running!")
                else:
                    stop_all_scripts()
            
            elif choice == '4':
                # List running depot instances
                if not running_processes:
                    print("No depot instances are currently running!")
                else:
                    print("\nCurrently Running Depot Instances:")
                    for instance_id, info in running_processes.items():
                        elapsed = datetime.now() - info["start_time"]
                        elapsed_str = f"{elapsed.seconds // 60}m {elapsed.seconds % 60}s"
                        print(f"- {info['depot_name']} (Running for: {elapsed_str})")
            
            elif choice == '5':
                # Exit
                if running_processes:
                    confirm = input("There are still running depot instances. Stop all and exit? (y/n): ")
                    if confirm.lower() == 'y':
                        stop_all_scripts()
                        break
                    else:
                        continue
                else:
                    break
            
            else:
                print("Invalid choice! Please enter a number between 1 and 5.")
                
    except KeyboardInterrupt:
        print("\nProgram interrupted by user")
        if running_processes:
            confirm = input("Stop all running depot instances before exiting? (y/n): ")
            if confirm.lower() == 'y':
                stop_all_scripts()
    except Exception as e:
        logging.exception(f"Unexpected error: {str(e)}")
        print(f"An unexpected error occurred: {str(e)}")
    finally:
        logging.info("Multi-Depot Cement Bidding System shutting down")
        print("\nShutting down Multi-Depot Cement Bidding System")
        
        # Make sure all processes are stopped
        stop_all_scripts()

if __name__ == "__main__":
    main()