from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException, StaleElementReferenceException
from bs4 import BeautifulSoup
from selenium.webdriver.common.action_chains import ActionChains
import time
import logging
from webdriver_manager.chrome import ChromeDriverManager
import json
import datetime

# Set up logging
logging.basicConfig(
    filename='bidding_log.log',
    level=logging.INFO,
    format='%(asctime)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

# Get user input at the very beginning - only quantity
try:
    quantities_input = input("Enter desired quantities (separated by commas): ")
    desired_quantities = [float(q.strip()) for q in quantities_input.split(",")]
    logging.info(f"User specified quantities: {desired_quantities}")
    print(f"Will bid for quantities: {desired_quantities}")
except ValueError:
    print("Please enter valid numbers for quantities.")
    logging.error("Invalid quantity input")
    exit()

# Data structures for storing bid information
data_set = []
data_set_clubid_list = []
dataSingle = []  # For single bids

# Global variables
count = 0
singleCount = 0
quantity_bids = {qty: [] for qty in desired_quantities}

def add_data(rowid, amount):
    data = {
        "rowid": rowid,
        "amount": amount
    }
    data_set.append(data)
    dataSingle.append(data)  # Also add to dataSingle for processing


def data_set_clubid(rowid, amount, clubid):
    data = {
        "rowid": rowid,
        "amount": amount,
        "clubid": clubid,
    }
    data_set_clubid_list.append(data)


def get_timer_info(driver):
    """Get timer information from the webpage."""
    try:
        timer_element = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.ID, '__xmlview0--timer-inner'))
        )
        timer_text = timer_element.text
        return timer_text
    except (NoSuchElementException, TimeoutException) as e:
        logging.error(f"Error getting timer information: {e}")
        return "Timer not found"


def wait_for_timer_and_click_search2():
    try:
        while True:
            try:
                timer2_element = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.ID, '__xmlview0--timer-inner'))
                )
                current_time = timer2_element.text
                print(f"Current timer: {current_time}")
                logging.info(f"Current timer: {current_time}")
                
                if current_time == 'Starts in 0:0:4':
                    print("Timer reached Starts in 0:0:4, clicking search box.")
                    logging.info("Timer reached Starts in 0:0:4, clicking search box.")
                    
                    search_box = WebDriverWait(driver, 5).until(
                        EC.element_to_be_clickable((By.ID, '__button3-BDI-content'))
                    )
                    search_box.click()
                    
                    # Wait for the page to stabilize after clicking search
                    print("Waiting for page to stabilize after search...")
                    logging.info("Waiting for page to stabilize after search...")
                    
                    # Wait for the table to refresh
                    WebDriverWait(driver, 6).until(
                        EC.staleness_of(timer2_element)
                    )
                    
                    # Wait for the table to be present again
                    WebDriverWait(driver, 6).until(
                        EC.presence_of_element_located((By.ID, '__xmlview0--idUtclVCVendorAssignmentTable-tblBody'))
                    )
                    
                    print("Page stabilized after search.")
                    logging.info("Page stabilized after search.")
                    break
                    
                if 'Expires in' in current_time:
                    print("Bid is active with 'Expires in' timer.")
                    logging.info("Bid is active with 'Expires in' timer.")
                    break
                    
            except StaleElementReferenceException:
                print("StaleElementReferenceException occurred. Retrying...")
                logging.warning("StaleElementReferenceException occurred. Retrying...")
                continue
                
            time.sleep(1)
    except (NoSuchElementException, TimeoutException) as e:
        print(f"Error tracking the timer or clicking the search box: {e}")
        logging.error(f"Error tracking the timer or clicking the search box: {e}")
        return False

def print_updated_row(row_id):
    try:
        # Wait for the table to refresh after bid submission
        time.sleep(1)
        
        # Find the table body
        tbody = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, '__xmlview0--idUtclVCVendorAssignmentTable-tblBody'))
        )
        
        # Get updated table content
        tbody_html = tbody.get_attribute('outerHTML')
        soup = BeautifulSoup(tbody_html, 'html.parser')
        rows = soup.find_all('tr')
        
        # Find the specific row by row_id
        current_row_id = -1
        for row in rows:
            current_row_id += 1
            if current_row_id == row_id:
                cells = row.find_all('td')
                cell_data = [cell.get_text(strip=True) for cell in cells]
                
                # Print and log the updated row data
                print(f"Updated row {row_id} data: {cell_data}")
                logging.info(f"Updated row {row_id} data: {cell_data}")
                return True
        
        print(f"Row {row_id} not found in the updated table")
        logging.warning(f"Row {row_id} not found in the updated table")
        return False
        
    except Exception as e:
        print(f"Error retrieving updated row {row_id}: {e}")
        logging.error(f"Error retrieving updated row {row_id}: {e}")
        return False
    
def enter_bid_for_single_item(item):
    try:
        input_id = f"__xmlview0--idBidAmount-__xmlview0--idUtclVCVendorAssignmentTable-{item['rowid']}-inner"
        bid_amt = int(item['amount'])
        
        # Use a more robust wait with retry logic
        max_retries = 3
        for attempt in range(max_retries):
            try:
                # Wait for the input field to be present and clickable
                bid_input = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.ID, input_id))
                )
                
                # Use JavaScript to ensure the element is in view
                driver.execute_script("arguments[0].scrollIntoView(true);", bid_input)
                
                # Clear and enter the bid amount
                bid_input.clear()
                bid_input.send_keys(str(bid_amt))
                print(f"Entered bid amount: {bid_amt} for row {item['rowid']}")
                logging.info(f"Entered bid amount: {bid_amt} for row {item['rowid']}")
                return True
            except StaleElementReferenceException:
                if attempt < max_retries - 1:
                    print(f"Stale element on attempt {attempt+1}, retrying...")
                    logging.warning(f"Stale element on attempt {attempt+1}, retrying...")
                    time.sleep(1)
                else:
                    raise
    except Exception as e:
        print(f"Error entering bid for row {item['rowid']}: {e}")
        logging.error(f"Error entering bid for row {item['rowid']}: {e}")
        return False

def enter_bid_amount_and_save():
    try:
        if singleCount > 0:
            # Wait for the page to stabilize after clicking search
            time.sleep(1)
            
            # Import ThreadPoolExecutor
            from concurrent.futures import ThreadPoolExecutor
            
            # Use ThreadPoolExecutor to process items in parallel
            # Adjust max_workers based on your system and application's performance
            with ThreadPoolExecutor(max_workers=min(10, singleCount)) as executor:
                # Submit all bid entry tasks to the executor
                futures = [executor.submit(enter_bid_for_single_item, item) for item in dataSingle]
                
                # Wait for all futures to complete (optional, since the 'with' block will wait anyway)
                # This gives us more control over handling results
                from concurrent.futures import as_completed
                for future in as_completed(futures):
                    try:
                        result = future.result()
                    except Exception as exc:
                        print(f"Task generated an exception: {exc}")
                        logging.error(f"Task generated an exception: {exc}")
            
            # After entering all bid amounts in parallel, click save with retry logic
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    save_button = WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((By.ID, '__xmlview0--idUtclsaveTxt-inner'))
                    )
                    
                    # Use JavaScript to ensure the save button is in view
                    driver.execute_script("arguments[0].scrollIntoView(true);", save_button)
                    
                    # Click the save button
                    save_button.click()
                    print("Save button clicked.")
                    logging.info("Save button clicked.")
                    
                    # Wait for confirmation dialog to appear
                    time.sleep(0.2)  # Increased wait time for dialog to appear
                    
                    # Try multiple approaches to confirm the first dialog (Yes button)
                    confirmation_methods = [
                        # Method 1: Find by ID and click directly
                        lambda: WebDriverWait(driver, 8).until(
                            EC.element_to_be_clickable((By.ID, '__mbox-btn-0'))
                        ).click(),
                        
                        # Method 2: Find by ID and click via JavaScript
                        lambda: driver.execute_script(
                            "document.getElementById('__mbox-btn-0').click();"
                        ),
                        
                        # Method 3: Find by querySelector and click via JavaScript
                        lambda: driver.execute_script(
                            "document.querySelector('#__mbox-btn-0').click();"
                        ),
                        
                        # Method 4: Find by XPath for button content
                        lambda: WebDriverWait(driver, 8).until(
                            EC.element_to_be_clickable((By.XPATH, "//bdi[text()='Yes']/ancestor::button"))
                        ).click(),
                        
                        # Method 5: Find by XPath for direct path
                        lambda: WebDriverWait(driver, 8).until(
                            EC.element_to_be_clickable((By.XPATH, "/html/body/div[1]/div[4]/footer/div/button[1]"))
                        ).click(),
                        
                        # Method 6: Find by text content and click via JavaScript
                        lambda: driver.execute_script(
                            "Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Yes')).click();"
                        ),
                        
                        # Method 7: Send Enter key as last resort
                        lambda: ActionChains(driver).send_keys(Keys.ENTER).perform()
                    ]
                    
                    # Try each method until one succeeds
                    for i, method in enumerate(confirmation_methods):
                        try:
                            method()
                            print(f"First confirmation dialog (Yes) handled successfully with method {i+1}")
                            logging.info(f"First confirmation dialog (Yes) handled successfully with method {i+1}")
                            break
                        except Exception as e:
                            print(f"Method {i+1} failed for Yes button: {e}")
                            logging.warning(f"Method {i+1} failed for Yes button: {e}")
                            if i == len(confirmation_methods) - 1:
                                print("All confirmation methods failed for Yes button")
                                logging.error("All confirmation methods failed for Yes button")
                    
                    # Wait for the second dialog (OK button) to appear
                    time.sleep(0.2)
                    
                    # Try multiple approaches to confirm the second dialog (OK button)
                    ok_dialog_methods = [
                        # Method 1: Find by ID and click directly
                        lambda: WebDriverWait(driver, 8).until(
                            EC.element_to_be_clickable((By.XPATH, "//bdi[text()='OK']/ancestor::button"))
                        ).click(),                        
                        
                        # Method 2: Find by ID and click via JavaScript
                        lambda: driver.execute_script(
                            "document.getElementById('__mbox-btn-4').click();"
                        ),
                        
                        # Method 3: Find by querySelector and click via JavaScript
                        lambda: driver.execute_script(
                            "document.querySelector('#__mbox-btn-4').click();"
                        ),
                        
                        # Method 4: Find by XPath for button content
                        
                        lambda: WebDriverWait(driver, 8).until(
                            EC.element_to_be_clickable((By.ID, '__mbox-btn-4'))
                        ).click(),
                        
                        # Method 5: Find by XPath using the provided selector
                        lambda: WebDriverWait(driver, 8).until(
                            EC.element_to_be_clickable((By.XPATH, "//*[@id='__mbox-btn-4']"))
                        ).click(),
                        
                        # Method 6: Find by text content and click via JavaScript
                        lambda: driver.execute_script(
                            "Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('OK')).click();"
                        ),
                        
                        # Method 7: Send Enter key as last resort
                        lambda: ActionChains(driver).send_keys(Keys.ENTER).perform()
                    ]
                    
                    # Try each method until one succeeds for the OK button
                    for i, method in enumerate(ok_dialog_methods):
                        try:
                            method()
                            print(f"Second confirmation dialog (OK) handled successfully with method {i+1}")
                            logging.info(f"Second confirmation dialog (OK) handled successfully with method {i+1}")
                            break
                        except Exception as e:
                            print(f"Method {i+1} failed for OK button: {e}")
                            logging.warning(f"Method {i+1} failed for OK button: {e}")
                            if i == len(ok_dialog_methods) - 1:
                                print("All confirmation methods failed for OK button")
                                logging.error("All confirmation methods failed for OK button")
                    
                    # Add delay after confirming both dialogs
                    print("Retrieving updated bid information...")
                    logging.info("Retrieving updated bid information...")

                    # Print updated information for each row that was updated
                    for item in dataSingle:
                        print_updated_row(item['rowid'])
                    
                    time.sleep(60)
                    
                    break
                except StaleElementReferenceException:
                    if attempt < max_retries - 1:
                        print(f"Stale element on save button attempt {attempt+1}, retrying...")
                        logging.warning(f"Stale element on save button attempt {attempt+1}, retrying...")
                        time.sleep(1)
                    else:
                        raise
                        
    except Exception as e:
        print(f"Error entering bid amount or saving: {e}")
        logging.error(f"Error entering bid amount or saving: {e}")

def process_bids(rows):
    global count, singleCount, dataSingle
    
    # Reset counters and data for this depot
    dataSingle = []  # Reset for this search cycle
    singleCount = 0
    count = 0
    found_any_match = False
    
    # List of companies to exclude
    excluded_companies = ['BHIM LAL JAISWAL', 'RAJU BUILDING MATERIAL', 'MAHALASA CONSTRUCTIONS PVT LTD', 'ABHILASHA ENTERPRISES',
                      'PAHALWAN TRADERS', 'TARIKH BULD. MATERIAL', 'ABHILASHA ENTERPRISES']
    
    # Store all rows with their data for processing
    all_rows = []
    
    # First pass: gather all row data
    rowid = -1
    for row in rows:
        rowid += 1
        cells = row.find_all('td')
        cell_data = [cell.get_text(strip=True) for cell in cells]
        
        print(f"Found row: {cell_data}")
        logging.info(f"Bid data: {cell_data}")
        
        # Check if the company is in the excluded list
        if len(cell_data) > 20 and cell_data[20] in excluded_companies:
            logging.info(f"Skipping row {rowid} due to excluded company: {cell_data[20]}")
            continue
        
        if len(cell_data) <= 12:
            logging.info("Row has insufficient data, skipping")
            continue
        
        # Extract club ID
        try:
            club_identifier = cell_data[2]
            club_identifier = club_identifier.replace("Object Identifier", "")
            current_clubid = int(club_identifier) if club_identifier.strip() else 0
        except (ValueError, IndexError):
            logging.info(f"Could not extract club ID from row {rowid}, using 0")
            current_clubid = 0
        
        # Extract quantity
        try:
            quantity = float(cell_data[11]) if len(cell_data) > 10 and cell_data[11].replace('.', '', 1).isdigit() else 0
        except (ValueError, IndexError):
            quantity = 0
        
        # Calculate bid amount - 2% less than the base price
        if len(cell_data) > 13 and cell_data[13].replace('.', '', 1).isdigit():
            value_to_calculate = int(cell_data[13])
            val = (value_to_calculate * 2) // 100
            actval = value_to_calculate - val
            final = int(actval)
            
            # Store row data for processing
            row_data = {
                'rowid': rowid,
                'quantity': quantity,
                'bid_amount': final,
                'clubid': current_clubid,
                'cell_data': cell_data
            }
            
            all_rows.append(row_data)
    
    # Check if we found any rows
    if not all_rows:
        logging.info(f"No qualifying rows found")
        return False
    
    # For each desired quantity, try to find matching bids
    for desired_quantity in desired_quantities:
        logging.info(f"Processing for desired quantity: {desired_quantity}")
        print(f"Processing for desired quantity: {desired_quantity}")
        
        # Separate rows by club ID
        rows_by_clubid = {}
        rows_without_clubid = []
        
        for row in all_rows:
            if row['clubid'] > 0:
                if row['clubid'] not in rows_by_clubid:
                    rows_by_clubid[row['clubid']] = []
                rows_by_clubid[row['clubid']].append(row)
            else:
                rows_without_clubid.append(row)
        
        # CASE 1: Look for club ID group with exact quantity match
        for clubid, group in rows_by_clubid.items():
            total_quantity = sum(row['quantity'] for row in group)
            if abs(total_quantity - desired_quantity) < 0.01:
                logging.info(f"Found club ID group with exact combined quantity: Club ID {clubid}, Total Quantity: {total_quantity}")
                
                bids_for_quantity = []
                for row in group:
                    data_set_clubid(row['rowid'], row['bid_amount'], clubid)
                    add_data(row['rowid'], row['bid_amount'])
                    bids_for_quantity.append({'rowid': row['rowid'], 'amount': row['bid_amount']})
                    singleCount += 1
                
                quantity_bids[desired_quantity] = bids_for_quantity
                found_any_match = True
                print(f"Found combination of {len(group)} rows with club ID {clubid} that match the desired quantity {desired_quantity}")
                break  # Continue to next desired quantity
        
            # If we found a match with club ID, continue to next quantity
            if desired_quantity in quantity_bids and quantity_bids[desired_quantity]:
                continue
        
        # CASE 2: Look for exact quantity match in a single row
        exact_matches = [row for row in all_rows if abs(row['quantity'] - desired_quantity) < 0.01]
        
        if exact_matches and not (desired_quantity in quantity_bids and quantity_bids[desired_quantity]):
            row = exact_matches[0]
            logging.info(f"Found exact quantity match: Row {row['rowid']}, Quantity: {row['quantity']}")
            
            if row['clubid'] > 0:
                data_set_clubid(row['rowid'], row['bid_amount'], row['clubid'])
            
            add_data(row['rowid'], row['bid_amount'])
            quantity_bids[desired_quantity] = [{'rowid': row['rowid'], 'amount': row['bid_amount']}]
            singleCount += 1
            count += 1
            found_any_match = True
                
            print(f"Found exact quantity match in row {row['rowid']} for {desired_quantity}")
            continue  # Continue to next desired quantity
        
        # CASE 3: Look for combinations of rows without club IDs
        if rows_without_clubid and not (desired_quantity in quantity_bids and quantity_bids[desired_quantity]):
            # Try to find a combination of rows without club IDs that match the desired quantity
            def find_combination(rows, target, start_idx=0, current_combination=None):
                if current_combination is None:
                    current_combination = []
                    
                current_sum = sum(row['quantity'] for row in current_combination)
                
                if abs(current_sum - target) < 0.01:
                    return current_combination
                
                if current_sum > target or start_idx >= len(rows):
                    return None
                
                # Try including the current row
                result = find_combination(rows, target, start_idx + 1, current_combination + [rows[start_idx]])
                if result:
                    return result
                    
                # Try excluding the current row
                return find_combination(rows, target, start_idx + 1, current_combination)
            
            combination = find_combination(rows_without_clubid, desired_quantity)
            if combination:
                logging.info(f"Found combination of {len(combination)} rows without club IDs that match the desired quantity {desired_quantity}")
                
                bids_for_quantity = []
                for row in combination:
                    add_data(row['rowid'], row['bid_amount'])
                    bids_for_quantity.append({'rowid': row['rowid'], 'amount': row['bid_amount']})
                    singleCount += 1
                    count += 1
                
                quantity_bids[desired_quantity] = bids_for_quantity
                found_any_match = True
                print(f"Found combination of {len(combination)} rows that match the desired quantity {desired_quantity}")
                continue  # Continue to next desired quantity
        
        # If we reached here, we couldn't find a match for this quantity
        print(f"Could not find a suitable combination for the desired quantity of {desired_quantity}")
        logging.info(f"Could not find rows that match the desired quantity of {desired_quantity}")
    
    # Return True if we found at least one match
    return found_any_match


def perform_search_and_process():
    global singleCount, dataSingle, data_set, data_set_clubid_list, quantity_bids
    
    # Reset all bid data
    data_set = []
    data_set_clubid_list = []
    dataSingle = []
    singleCount = 0
    
    # Initialize bids for each quantity
    quantity_bids = {qty: [] for qty in desired_quantities}
    
    try:
        search_box = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, '__button3-BDI-content')))
        search_box.click()
        logging.info("Search button clicked")
        
        # Wait for results to load
        time.sleep(1)
        
        # Check if there's a table with data
        try:
            tbody = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.ID, '__xmlview0--idUtclVCVendorAssignmentTable-tblBody'))
            )
            
            # Get timer information
            timer_info = get_timer_info(driver)
            logging.info(f"Current timer status: {timer_info}")
            
            # Get table content
            tbody_html = tbody.get_attribute('outerHTML')
            soup = BeautifulSoup(tbody_html, 'html.parser')
            rows = soup.find_all('tr')
            
            if len(rows) > 0:
                first_row = rows[0]
                cells = first_row.find_all('td')
                cell_data = [cell.get_text(strip=True) for cell in cells]
                
                if 'No data' in cell_data:
                    logging.info("Search result: No bids available")
                    return False
                else:
                    bid_count = len(rows)
                    logging.info(f"Search result: {bid_count} bids found with timer: {timer_info}")
                    
                    # Process bids based on desired quantities
                    print(f"Processing bids with desired quantities: {desired_quantities}")
                    logging.info(f"Processing bids with desired quantities: {desired_quantities}")

                    # Process bids
                    found_qualifying_bids = process_bids(rows)
                    
                    if found_qualifying_bids:
                        # If qualifying bids found, wait for timer and then place bids
                        logging.info("Qualifying bids found, watching timer")
                        wait_for_timer_and_click_search2()
                        logging.info("Timer function completed, proceeding to enter bid amounts")
                        print("Timer function completed, proceeding to enter bid amounts")

                        # After timer expires, enter bids and save
                        enter_bid_amount_and_save()
                        logging.info("Bid amounts entered and saved")
                        return True
                    else:
                        logging.info("No qualifying bids found")
                        return False
            else:
                logging.info("Search result: Empty table (no rows)")
                return False
                
        except (NoSuchElementException, TimeoutException) as e:
            logging.info("No table found, likely no bids available")
            return False
            
    except Exception as e:
        logging.error(f"Error during search and processing operation: {e}")
        return False


# Initialize browser
try:
    brave_path = "C:/Program Files/BraveSoftware/Brave-Browser/Application/brave.exe"

    options = Options()
    options.binary_location = brave_path
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

    driver.get('https://www.eye2serve.com:9001/sap/bc/ui5_ui5/ui2/ushell/shells/abap/FioriLaunchpad.html')

    # Login
    username_field = driver.find_element(By.ID, 'USERNAME_FIELD-inner')
    password_field = driver.find_element(By.ID, 'PASSWORD_FIELD-inner')

    username_field.send_keys('2900034')
    password_field.send_keys('Devesh3321@#')
    password_field.send_keys(Keys.RETURN)

    time.sleep(6)
    logging.info("Logged in to the system")

    # Click on E-Bidding button
    try:
        ebidding_button = WebDriverWait(driver, 30).until(EC.presence_of_element_located((By.ID, '__content6')))
        ebidding_button.click()
        logging.info("Clicked on E-Bidding button")
    except (NoSuchElementException) as e:
        logging.error(f"Failed to click E-Bidding button: {e}")

    # Handle new tab and perform initial search
    original_handle = driver.current_window_handle
    try:
        WebDriverWait(driver, 10).until(EC.new_window_is_opened)
    except TimeoutException:
        logging.error("New tab didn't open within the specified time.")
        driver.quit()
        exit()

    for handle in driver.window_handles:
        if handle != original_handle:
            driver.switch_to.window(handle)
            break

    try:
        search_button = WebDriverWait(driver, 30).until(EC.presence_of_element_located((By.ID, '__button0-BDI-content')))
        search_button = WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.ID, '__button0-BDI-content')))
        search_button.click()
        logging.info("Clicked on initial search button in new tab")
    except (NoSuchElementException, TimeoutException) as e:
        logging.error(f"Error finding or clicking search button: {e}")
        driver.quit()
        exit()

    # Enter fixed search criteria
    try:
        # Enter the fixed ship from plant
        ship_box = WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.ID, '__xmlview0--ididUtclVCShipFromPlant-inner')))
        time.sleep(1)
        ship_box.send_keys('TANDA CEMENT WORKS')
        logging.info("Entered 'TANDA CEMENT WORKS' in ship from plant field")
        
        # Enter the fixed depot
        ship_box2 = WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.ID, '__xmlview0--idUtclVCDepot-inner')))
        time.sleep(1)
        ship_box2.send_keys('MAU')
        logging.info("Entered 'MAU' in depot field")
    except (NoSuchElementException) as e:
        logging.error(f"Error entering search criteria: {e}")

    # Initial search
    bids_found = perform_search_and_process()

    # Continue searching every 10 seconds until qualifying bids are found
    try:
        if not bids_found:
            logging.info("Starting continuous search loop every 10 seconds until qualifying bids are found")
            while not bids_found:
                time.sleep(10)
                logging.info("Performing periodic search...")
                bids_found = perform_search_and_process()
                
        if bids_found:
            logging.info("Qualifying bids found and processed. Keeping session open.")
            # Keep the session open - add a loop to keep the script running
            while True:
                try:
                    time.sleep(60)  # Check every minute
                    logging.info("Session maintained. Press Ctrl+C to exit.")
                except KeyboardInterrupt:
                    raise KeyboardInterrupt
        else:
            logging.info("No qualifying bids found. Keeping session open.")
            while True:
                try:
                    time.sleep(60)  # Check every minute
                    logging.info("Session maintained. Press Ctrl+C to exit.")
                except KeyboardInterrupt:
                    raise KeyboardInterrupt                                            
    except KeyboardInterrupt:
        logging.info("Script terminated by user")
        driver.quit()
except Exception as e:
    logging.error(f"Error occurred: {e}")
    driver.quit()